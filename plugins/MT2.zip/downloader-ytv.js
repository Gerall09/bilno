import ytdl from "ytdl-core";

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`*Example:* .${command} https://www.youtube.com/xxxxxxx`);
    conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key }});
    try {
        let info = await ytdl.getInfo(text, {
            lang: "id",
        });
        let title = info.videoDetails.title;
        let stream = ytdl(text, {
            filter: "videoandaudio",
        });
        let chunks = [];
        stream.on("data", (chunk) => {
            chunks.push(chunk);
        });
        await new Promise((resolve, reject) => {
            stream.on("end", resolve);
            stream.on("error", reject);
        });
        let buffer = Buffer.concat(chunks);
        let size = buffer.length;
        let views = info.videoDetails.viewCount;
        let likes = info.videoDetails.likes;
        let uploadDate = info.videoDetails.uploadDate;
        
        let response = `
📹 *Title:* ${title}
📏 *Size:* ${formatBytes(size)}
👀 *Views:* ${views}
👍 *Likes:* ${likes}
📅 *Upload Date:* ${uploadDate}
        `;
        
        conn.sendFile(m.chat, buffer, '', `*${title}*.mp4\n\n${response}`, m);
    } catch (error) {
        console.error(error);
        m.reply("An error occurred while processing the video.");
    }
};

handler.help = ['ytmp4']
handler.tags = ['downloader']
handler.command = ['ytmp4', 'ytv']
export default handler;

function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}