import fetch from 'node-fetch';

let handler = async (m, { conn, text }) => {
  if (!text) throw 'Judulnya?'; // If no text is provided, prompt for a title.
  
  m.reply('Searching for lyrics...'); // Inform the user that a search is in progress.
  
  try {
    // Fetch lyrics from the new API
    let res = await fetch(`https://aemt.me/lirik?text=${encodeURIComponent(text)}`);
    if (!res.ok) throw new Error('Failed to fetch'); // Check if the request was successful
    
    let data = await res.json();
    console.log('API Response:', data); // Log the API response for debugging

    // Check if the response status is true
    if (!data.status) throw new Error('Lyrics not found');

    // Extract relevant information from the response
    let { result } = data;
    if (!result) throw new Error('Invalid response structure');

    let { lyrics, title, artist, thumbnail } = result;

    if (!lyrics || !title || !artist || !thumbnail) {
      console.error('Incomplete data:', result); // Log the incomplete data for debugging
      throw new Error('Incomplete data received');
    }

    // Send the thumbnail image and lyrics to the chat
    conn.sendFile(m.chat, thumbnail, 'thumbnail.jpg', `*${title}* by *${artist}*\n\n${lyrics}`, m);
  } catch (e) {
    console.error(e); // Log the error for debugging
    m.reply('Tidak Dapat Menemukan Apa Yang Kamu Cari'); // Inform the user that the lyrics couldn't be found
  }
};

// Define command help, tags, and limit
handler.help = ['liriklagu'];
handler.tags = ['internet'];
handler.command = /^(liriklagu|lirik|lyrics)$/i;
handler.limit = true;

export default handler;