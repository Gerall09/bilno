import fetch from 'node-fetch'
import { lookup } from 'mime-types'
import { URL_REGEX } from '@adiwajshing/baileys'

let handler = async (m, { conn, text }) => {
    // Send reaction to indicate processing
    conn.sendMessage(m.chat, {
        react: {
            text: '🔍',
            key: m.key,
        }
    })

    // Validate input
    if (!text || !text.match(URL_REGEX)) throw 'Input valid Pinterest URL'

    try {
        // Fetch the download link using CIFUMO API
        let res = await pinterest(text)
        let mime = await lookup(res)
        let link = await shortUrl(res)

        // Send the downloadable content back to the chat
        await conn.sendMessage(m.chat, { [mime.split('/')[0]]: { url: res }, caption: `Success Download: ${link}` }, { quoted: m })
    } catch (error) {
        throw 'Failed to download content. Please ensure the URL is correct and try again.'
    }
}

handler.help = ['pindl <link>']
handler.tags = ['downloader']
handler.command = /^pindl$/i

handler.limit = 2
handler.register = true;

export default handler

// Function to fetch download link from CIFUMO API
async function pinterest(url) {
    let res = await fetch(`https://rest.cifumo.biz.id/api/downloader/pindl?url=${encodeURIComponent(url)}`)
    let json = await res.json()

    if (!json.status) throw 'Download failed'
    return json.data
}

// Function to shorten URLs
async function shortUrl(url) {
    return await (await fetch(`https://tinyurl.com/api-create.php?url=${url}`)).text()
}