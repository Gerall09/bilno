let handler = async (m) => {
    global.db.data.chats[m.chat].isBanned = false
    m.reply('Done Membuka Mute Untuk Grup Ini.!')
}
handler.help = ['unmute']
handler.tags = ['unmute']
handler.command = /^(unmute)$/i
handler.admin = true
handler.botAdmin = true
handler.group = true

export default handler